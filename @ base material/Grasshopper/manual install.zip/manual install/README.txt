************** NOTA BENE **************

Questi files e questa procedura sono SOLO PER I CASI IN CUI IL PACKAGEMANAGER NON DOVESSE FUNZIONARE NEMMENO DOPO AVER RIAVVIATO RHINO CON UN FILE VUOTO ED AVER ESEGUITO PACKAGEMANAGER COME PRIMO COMANDO.

***************************************


1. Verificare che TUTTI i files nella cartella MoveContentToLibraries (e relative sottocartelle) siano sbloccati. Vedi: https://wiki.mcneel.com/rhino/unblockplugin

2. Aprire Rhino e Grasshopper

3. Trascinare uno alla volta i files della cartella DragIntoOpenRhino dentro la finestra di Rhino

4. Da Grasshopper, andare nel menu File > Special Folders > Components folder

5. Spostare il contenuto della cartella MoveContentToLibraries nella cartella che si aprirà

6. Riavviare Rhino

