
1. Verificare che TUTTI i files nella cartella MoveContentToLibraries (e relative sottocartelle) siano sbloccati. Vedi: https://wiki.mcneel.com/rhino/unblockplugin

2. Aprire Rhino e Grasshopper

3. Da Grasshopper, andare nel menu File > Special Folders > Components folder

4. Spostare il contenuto della cartella MoveContentToLibraries nella cartella che si aprirà

5. Riavviare Rhino